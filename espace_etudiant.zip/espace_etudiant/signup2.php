<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signup2style.css">
    <title>signup</title>
</head>
<body>
    <?php 
include_once 'connexion.php' ; 

$nom = $_POST['nom'] ;
$prenom = $_POST['prenom'] ;
$cne = $_POST['cne'] ;
$email = $_POST['email'] ;
$tel = $_POST['tel'] ;
$xpl=explode('.',$_FILES['photo']['name']);
$file_ext = strtolower(end($xpl));

$username = $_POST['username'] ;
$password = $_POST['password'] ; 

$sql = "INSERT INTO etudiant(user,nom,prenom,cne,email,tel,photo) VALUES ('$username','$nom' ,'$prenom','$cne','$email','$tel','$file_ext');";
$result1 = mysqli_query ($connex,$sql) ;
if($result1==1){
    $file_tmp = $_FILES['photo']['tmp_name'];
    move_uploaded_file($file_tmp,"photo/".$username.".".$file_ext);
    $requete = "SELECT id FROM etudiant where 
    user = '".$username."' ";
    $result = mysqli_query($connex,$requete);
    $row= mysqli_fetch_assoc($result);
    $id= $row['id'];
$sql = "INSERT INTO compte(id,user,pass) VALUES ('$id','$username' ,'$password' );";
$result2 = mysqli_query ($connex,$sql) ;
echo "<center><h1>enregistrement reussi</h1>
<h1>".$result1."</h1>
<p>vous êtes enregistré sous le nom d'utilisateur: 
    <br>
    <span>".$username."</span>
    
</p> 
<p><a href=\"index.php\">page d'acceuil</a></p>

</center>";
}else{
    echo "<center><h1>:username OU cne invalide:</h1><a class=\"res\" href=\"signup.php\">réessayer</a></center>";}


?>



</body>
</html>
