<?php session_start(); 
if(isset($_POST['decx'])){ session_unset();}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>espace_etudiant</title> 
</head>
<body>
    <?php if(isset($_SESSION['username']) and isset($_SESSION['password'])){
        header("Location: compte.php");
        exit;
    }
    
     ?>
<a href="signup.php">nouvel utilisateur</a>
<br>
       
<center>
            <p class="ensat">espace etudiant</p>
        </center>
        <center>
            <form action="compte.php" method="POST" >
                <p class="name" >Username : </p>
                <input type="text" name="username" required value="<?php if(isset($_SESSION['user'])){
                    echo $_SESSION['user'];
                    unset($_SESSION['user']);} ?>"> 
                <br>
                <p class="mp">Mot de passe : </p>
                <input type="password" name="password" required> <br><br><br>
                <input class="submit"  type="submit" name="submit" value="Login">
                <div><?php if(isset($_SESSION['eror'])){
                    echo $_SESSION['eror'];
                    unset($_SESSION['eror']);
                } ?></div>
            </form>
            
        </center> 
</body>
</html>