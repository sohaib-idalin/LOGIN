<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="comptestyle.css">
    <title>espace etuduant</title>
</head>
<body>
    <?php
    include_once 'connexion.php' ;
    
    if(isset($_SESSION['username']) and isset($_SESSION['password'])){
        goto D;
    }
    

    if(isset($_POST['username']) and isset($_POST['password'])){
        $_SESSION['username']=$_POST['username'];
        $_SESSION['password']=$_POST['password'];
    


        D:
        $requete = "SELECT id FROM compte where 
              user = '".$_SESSION['username']."' and pass = '".$_SESSION['password']."' ";
        $result = mysqli_query($connex,$requete);
        $resultcheck = mysqli_num_rows($result);
        
        if($resultcheck>0) // nom d'utilisateur et mot de passe correctes
        {
            $row= mysqli_fetch_assoc($result);
            $requete = "SELECT * FROM etudiant where 
              id = '".$row['id']."'  ";
            $result = mysqli_query($connex,$requete);
            $row= mysqli_fetch_assoc($result);
            echo "<div class='liste'><a href='liste.php'>LISTE DES ELEVES</a></div>";

            echo "<form action='index.php' method='post'> <input type='submit' name='decx' value='Deconnexion'></form>    
            <h1>:votre espace:</h1>
            <br><div class=\"cont\">
            <P>NOM:</P> <div class=\"info\"> ".$row['nom']." </div> <div class=\"photo\" ><img  alt=\"image\" src=\"./photo/".$row['user'].".".$row['photo']."\" width=\"150px\" height=\"150px\"><br> <p class='username'>".$row['user']." </p></div>
            <P>PRENOM:</P><div class=\"info\"> ".$row['prenom']."</div>
            <P>CNE:</P><div class=\"info\"> ".$row['cne']." </div>
            <P>EMAIL:</P><div class=\"info\"> ".$row['email']." </div><div></div>
            <P>TEL:</P><div class=\"info\"> ".$row['tel']." </div><div></div>";

        }
        else
        {   $_SESSION['eror']="incorect username or password";
            $_SESSION['user']=$_SESSION['username'];

            unset($_SESSION['username']);
            unset($_SESSION['password']);
            
            header("Location: index.php");
            
        }
    
    }
    else{
        echo "username et password vide <a href=\"index.php\">Page d'acceuil</a> ";
    }
    
    



    ?>



</div>
</body>
</html>