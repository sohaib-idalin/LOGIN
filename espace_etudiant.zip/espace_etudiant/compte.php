<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="comptestyle.css">
    <title>espace etuduant</title>
</head>
<body>
    <?php
    include_once 'connexion.php' ;
    
    
    

    if(isset($_POST['username']) and isset($_POST['password'])){
        $username=$_POST['username'];
    $password=$_POST['password'];


    
        $requete = "SELECT id FROM compte where 
              user = '".$username."' and pass = '".$password."' ";
        $result = mysqli_query($connex,$requete);
        $resultcheck = mysqli_num_rows($result);
        
        if($resultcheck>0) // nom d'utilisateur et mot de passe correctes
        {
            $row= mysqli_fetch_assoc($result);
            $requete = "SELECT * FROM etudiant where 
              id = '".$row['id']."'  ";
            $result = mysqli_query($connex,$requete);
            $row= mysqli_fetch_assoc($result);

            echo "<a class=\"a\" href=\"index.php\">Deconnexion</a>    
            <h1>:votre espace:</h1>
            <br><div class=\"cont\">
            <P>NOM:</P> <div class=\"info\"> ".$row['nom']." </div> <div class=\"photo\" ><img  alt=\"image\" src=\"./photo/".$row['user'].".".$row['photo']."\" width=\"150px\" height=\"150px\"><br> <p class='username'>".$row['user']." </p></div>
            <P>PRENOM:</P><div class=\"info\"> ".$row['prenom']."</div>
            <P>CNE:</P><div class=\"info\"> ".$row['cne']." </div>
            <P>EMAIL:</P><div class=\"info\"> ".$row['email']." </div><div></div>
            <P>TEL:</P><div class=\"info\"> ".$row['tel']." </div><div></div>";

        }
        else
        {
            
            echo "username OU password incorrect";
            echo " <span> ... </span> <a  href=\"index.php\">réessayer </a>"; // utilisateur ou mot de passe incorrect
            echo"<a style=\" display: block;
            position: absolute;
            width: 115px;
            top: 10px;
            right: 10px;
            color: rgb(51, 214, 243);
            border-width: 20px;
            border-color: black;
            text-decoration: none;
            background-color:rgb(33, 42, 73);
            border-radius: 15px;
            padding: 3px;
            padding-left: 8px;
            padding-right: 8px; \"  href=\"signup.php\">nouvel utilisateur</a>";
        }
    
    }
    else{
        echo "username et password vide <a href=\"index.php\">Page d'acceuil</a> ";
    }
    
    



    ?>



</div>
</body>
</html>