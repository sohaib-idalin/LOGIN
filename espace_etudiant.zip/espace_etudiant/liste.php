<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="liste.css">
    <title>LISTE DES ETUDIANT</title>
</head>
<body style="background-color: burlywood;">
<?php if(isset($_SESSION['username']) and isset($_SESSION['password'])){
    include_once 'connexion.php' ;
    echo "<div><a href='compte.php'>RETOUR</a></div>";
    $requete = "SELECT * FROM etudiant";
            $result = mysqli_query($connex,$requete);
            echo "<center><table border='1' ";
            echo "<tr>
            <td>nom</td>
            <td>prenom</td>
            <td>cne</td>
            <td>email</td>
            <td>tel</td>
            <td>PHOTO</td>
            </tr>";
            while($row= mysqli_fetch_assoc($result)){
                echo "<tr>
                <td>".$row['nom']."</td>
                <td>".$row['prenom']."</td>
                <td>".$row['cne']."</td>
                <td>".$row['email']."</td>
                <td>".$row['tel']."</td>
                <td><img  alt=\"image\" src=\"./photo/".$row['user'].".".$row['photo']."\" width=\"150px\" height=\"150px\"></td>
                </tr>";
            }
            echo "</table></center>";
    }else{ header("Location: index.php");}
    
    ?>
    
</body>
</html>